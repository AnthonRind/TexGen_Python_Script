from abaqusConstants import *
from abaqusGui import *
from kernelAccess import mdb, session
import os

thisPath = os.path.abspath(__file__)
thisDir = os.path.dirname(thisPath)


###########################################################################
# Class definition
###########################################################################

class _rsgTmp006_DB(AFXDataDialog):

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, form):

        # Construct the base class.
        #

        AFXDataDialog.__init__(self, form, 'Elastic Properties Calculator (EasyPBC)',
            self.OK|self.CANCEL, DIALOG_ACTIONS_SEPARATOR)
            

        okBtn = self.getActionButton(self.ID_CLICKED_OK)
        okBtn.setText('OK')
            
        GroupBox_4 = FXGroupBox(p=self, text='Model and analysis details', opts=FRAME_GROOVE)
        AFXTextField(p=GroupBox_4, ncols=20, labelText='Model name', tgt=form.partKw, sel=0)
        AFXTextField(p=GroupBox_4, ncols=20, labelText='Instance name', tgt=form.instKw, sel=0)
        AFXTextField(p=GroupBox_4, ncols=10, labelText='Mapping accuracy *', tgt=form.meshsensKw, sel=0)
        AFXTextField(p=GroupBox_4, ncols=2, labelText='Number of CPUs to be used **', tgt=form.CPUKw, sel=0)
        l = FXLabel(p=GroupBox_4, text='*  Mesh mapping accuracy of opposite sides should be within the above value.', opts=JUSTIFY_LEFT)
        l = FXLabel(p=GroupBox_4, text='** If number of CPUs exceeds the available, all available CPUs will be used.', opts=JUSTIFY_LEFT)
        GroupBox_1 = FXGroupBox(p=self, text='The homogenised elastic properties', opts=FRAME_GROOVE)
        FXCheckButton(p=GroupBox_1, text='E11 (Young modulus in X-direction)', tgt=form.E11Kw, sel=0)
        l = FXLabel(p=GroupBox_1, text='     + Dependent V12 (Poisson ratio in XY-direction)', opts=JUSTIFY_LEFT)
        l = FXLabel(p=GroupBox_1, text='     + Dependent V13 (Poisson ratio in XZ-direction) for 3D models', opts=JUSTIFY_LEFT)
        FXCheckButton(p=GroupBox_1, text='E22 (Young modulus in Y-direction)', tgt=form.E22Kw, sel=0)
        l = FXLabel(p=GroupBox_1, text='     + Dependent V21 (Poisson ratio in YX-direction)', opts=JUSTIFY_LEFT)
        l = FXLabel(p=GroupBox_1, text='     + Dependent V23 (Poisson ratio in YZ-direction) for 3D models', opts=JUSTIFY_LEFT)
        FXCheckButton(p=GroupBox_1, text='E33 (Young modulus in Z-direction) for 3D models', tgt=form.E33Kw, sel=0)
        l = FXLabel(p=GroupBox_1, text='     + Dependent V31 (Poisson ratio in ZX-direction)', opts=JUSTIFY_LEFT)
        l = FXLabel(p=GroupBox_1, text='     + Dependent V32 (Poisson ratio in ZY-direction)', opts=JUSTIFY_LEFT)
        FXCheckButton(p=GroupBox_1, text='G12 (Shear modulus in XY-direction)', tgt=form.G12Kw, sel=0)
        FXCheckButton(p=GroupBox_1, text='G13 (Shear modulus in XZ-direction) for 3D models', tgt=form.G13Kw, sel=0)
        FXCheckButton(p=GroupBox_1, text='G23 (Shear modulus in YZ-direction) for 3D models', tgt=form.G23Kw, sel=0)
        FXCheckButton(p=GroupBox_1, text='If ticked, only corresponding PBC will be created, elastic properties will not be estimated.', tgt=form.onlyPBCKw, sel=0)
        GroupBox_2 = FXGroupBox(p=self, text='Coefficient of Thermal Expansion (CTE)', opts=FRAME_GROOVE)
        FXCheckButton(p=GroupBox_2, text='Calculate CTE in X, Y, and Z direction', tgt=form.CTEKw, sel=0)
        AFXTextField(p=GroupBox_2, ncols=10, labelText='Initial temperature', tgt=form.intempKw, sel=0)
        AFXTextField(p=GroupBox_2, ncols=10, labelText='Final temperature', tgt=form.fntempKw, sel=0)
