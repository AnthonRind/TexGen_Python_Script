from abaqusGui import *
from abaqusConstants import ALL
import osutils, os


###########################################################################
# Class definition
###########################################################################

class _rsgTmp006_Form(AFXForm):

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, owner):
        
        # Construct the base class.
        #
        AFXForm.__init__(self, owner)
        self.radioButtonGroups = {}

        self.cmd = AFXGuiCommand(mode=self, method='feasypbc',
            objectName='easypbc', registerQuery=False)
        pickedDefault = ''
        self.partKw = AFXStringKeyword(self.cmd, 'part', True, 'Model-1')
        self.instKw = AFXStringKeyword(self.cmd, 'inst', True, 'Part-1-1')
        self.meshsensKw = AFXFloatKeyword(self.cmd, 'meshsens', True, 10E-8)
        self.CPUKw = AFXFloatKeyword(self.cmd, 'CPU', True, 1)
        self.E11Kw = AFXBoolKeyword(self.cmd, 'E11', AFXBoolKeyword.TRUE_FALSE, True, False)
        self.E22Kw = AFXBoolKeyword(self.cmd, 'E22', AFXBoolKeyword.TRUE_FALSE, True, False)
        self.E33Kw = AFXBoolKeyword(self.cmd, 'E33', AFXBoolKeyword.TRUE_FALSE, True, False)
        self.G12Kw = AFXBoolKeyword(self.cmd, 'G12', AFXBoolKeyword.TRUE_FALSE, True, False)
        self.G13Kw = AFXBoolKeyword(self.cmd, 'G13', AFXBoolKeyword.TRUE_FALSE, True, False)
        self.G23Kw = AFXBoolKeyword(self.cmd, 'G23', AFXBoolKeyword.TRUE_FALSE, True, False)
        self.onlyPBCKw = AFXBoolKeyword(self.cmd, 'onlyPBC', AFXBoolKeyword.TRUE_FALSE, True, False)
        self.CTEKw = AFXBoolKeyword(self.cmd, 'CTE', AFXBoolKeyword.TRUE_FALSE, True, False)
        self.intempKw = AFXFloatKeyword(self.cmd, 'intemp', True, 0.0)
        self.fntempKw = AFXFloatKeyword(self.cmd, 'fntemp', True, 100)

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def getFirstDialog(self):

        import _rsgTmp006_DB
        return _rsgTmp006_DB._rsgTmp006_DB(self)

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def doCustomChecks(self):

        # Try to set the appropriate radio button on. If the user did
        # not specify any buttons to be on, do nothing.
        #
        for kw1,kw2,d in self.radioButtonGroups.values():
            try:
                value = d[ kw1.getValue() ]
                kw2.setValue(value)
            except:
                pass
        return True

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def deactivate(self):
    
        try:
            osutils.remove(os.path.join('c:\\work\\abaqus_plugins\\EasyPBC V.1.4', '_rsgTmp006_DB.py'), force=True )
            osutils.remove(os.path.join('c:\\work\\abaqus_plugins\\EasyPBC V.1.4', '_rsgTmp006_DB.pyc'), force=True )
        except:
            pass
        try:
            osutils.remove(os.path.join('c:\\work\\abaqus_plugins\\EasyPBC V.1.4', '_rsgTmp006_Form.py'), force=True )
            osutils.remove(os.path.join('c:\\work\\abaqus_plugins\\EasyPBC V.1.4', '_rsgTmp006_Form.pyc'), force=True )
        except:
            pass
        AFXForm.deactivate(self)

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def getCommandString(self):

        cmds = 'import easypbc\n'
        cmds += AFXForm.getCommandString(self)
        return cmds

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def okToCancel(self):

        # No need to close the dialog when a file operation (such
        # as New or Open) or model change is executed.
        #
        return False
